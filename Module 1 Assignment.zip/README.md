# Employee Payment Slip Generator in Python

## Description
This project of Python work with employee data of 400 dynamically but randomnly generated employees,the main details include names, salaries, and sex. Based on specified conditions, and classified employees into levels based on conditions and generates payment slips for employees that are eligible.

## Features
- Randomly but auto generation of employee data (name, salary, and sex).
- Classiying employees levels like (`A1`, `A5-F`, or `Not Specified`) as per salary and sex.
- Generation of payment slips for employees as per conditions.
- Potential errors handling also included during processing.

## How to Run
1. Python should be installed (Python 3.x recommended).
2. Save the given code to a file named `main.py`.
3. Open a command prompt or terminal and navigate to the directory containing `main.py`.
4. Run the script, you may use the command below
   ```bash
   python main.py

Criteria for Employee Levels
A1: Employees with a salary between 10,000 and 20,000.
A5-F: Female employees with a salary between 7,500 and 30,000.
Not Specified: Employees not meeting the above criteria.

Expected Output
Pirnting the payment slip for employees who qualify.
Prints a final message when processing all employees is successsful.

Dependencies
Python 3.x
No external libraries are required. just import random.

# Employee Payment Slip Generator in R

## Description
This project of R work with employee data of 400 dynamically but randomnly generated employees,the main details include names, salaries, and sex. Based on specified conditions, and classified employees into levels based on conditions and generates payment slips for employees that are eligible.

## Features
- Randomly but auto generation of employee data (name, salary, and sex).
- Classiying employees levels like (`A1`, `A5-F`, or `Not Specified`) as per salary and sex.
- Generation of payment slips for employees as per conditions.
- Potential errors handling also included during processing.

## How to Run
1. R and Rstudio should be installed.
2. Save the given code to a file named `main.R`.
3. Run the script, main.R in Rstudio

Criteria for Employee Levels
A1: Employees with a salary between 10,000 and 20,000.
A5-F: Female employees with a salary between 7,500 and 30,000.
Not Specified: Employees not meeting the above criteria.

Expected Output
Pirnting the payment slip for employees who qualify along with Employee Level.
Prints a final message when processing all employees is successsful. (only in python code)

Dependencies
Python 3.x
Rstudio
No external libraries are required. just import random (in python)

Coder
Syeda Shagufta Alvi
