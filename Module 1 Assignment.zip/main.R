
employee_list <- paste("Employee", 1:400)  # Creating a list of employee names
salary <- sample(7000:30000, 400, replace = TRUE)  # Generating random salaries
sex <- sample(c("Male", "Female"), 400, replace = TRUE)  # Generating random sex for males and females

# Adding Employee Data into a Data Frame
employee_data <- data.frame(name = employee_list, salary = salary, sex = sex)

# Processing Employee Data
for (i in 1:nrow(employee_data)) {
 tryCatch(
   {
    employee <- employee_data$name[i]
    emp_salary <- employee_data$salary[i]
    emp_sex <- employee_data$sex[i]

    # Determining the  Employee Level as per conditions

    if (emp_salary > 10000 & emp_salary < 20000) {
    cat("Payment Slip is Generated for", employee, "(Level: A1)\n")
    }

    else if (emp_salary > 7500 & emp_salary < 30000 & emp_sex == "Female") {
    cat("Payment Slip is being Generated for", employee, "(Level: A5-F)\n")
  }
},
  error = function(e) {
    cat("Something is wrong please try later", i, ":", conditionMessage(e), "\n")
    }
  )
}

