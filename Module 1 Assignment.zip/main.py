# Step 1: Developing a Python program that fulfills the requirements outlined in the assignment description.


import random #imporing random because it is used below

EmployeeList = []  #initializing empty list
for x in range (1, 401):
    EmployeeList.append("Employee" + str(x))  # Step 2: creating a list variable with at least 400 workers, created dynamically and automicalyy.


Employee_data = []
for employee in EmployeeList: 
     salary = random.randint(7000, 30000)
     sex = random.choice(["Male", "Female"])
     Employee_data.append({"name": employee, "salary": salary, "sex": sex})

for Employee_info in Employee_data: # Step 3: Implementing a for loop in your Python program to generate payment slips for all workers in the list.


    try:
        employee = Employee_info["name"]
        salary = Employee_info["salary"]
        sex = Employee_info["sex"]

        if salary > 10000 and salary < 20000: # Step 4: Incorporating the specified conditional statements within the loop.
            EmployeeLevel= "A1"
        
        elif salary > 7500 and salary < 30000 and sex == 'female':
            EmployeeLevel = "A5-F"
        
        else:
            EmployeeLevel = "Not Specified"
            print ("Payment Slip is Generated for  " + employee + " Employee Level "+ EmployeeLevel)

    except Exception as e: #Step 5: Adding exception handling in your Python code to handle potential errors.


        print("Someting went wrong, Please try again, Later!"+ "Details Error:" + str(e) )
    
print("Execution successfull for all Employees!")